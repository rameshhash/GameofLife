﻿using System; 
using TGOLLibrary.Interface;

namespace TGOLLibrary.Implementation
{
    public class GridCreator : GridFactory
    {
        public override IGrid GetGrid(string gridType, int rows, int columns)
        {
            switch (gridType)
            {
                case "TwoD":
                    return new TwoDGrid(rows, columns);
                default:
                    throw new ApplicationException(string.Format("GridType '{0}' cannot be created", gridType));

            }
        }
    }
}
