﻿ 
using TGOLLibrary.Interface;

namespace TGOLLibrary.Implementation
{
    public abstract class GridFactory
    {
        public abstract IGrid GetGrid(string gridType, int rows, int columns);
    }
}
