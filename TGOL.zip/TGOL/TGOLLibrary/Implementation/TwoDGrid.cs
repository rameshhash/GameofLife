﻿using System;
using System.Collections.Generic;
using System.Text;
using TGOLLibrary.Interface;

namespace TGOLLibrary.Implementation
{
    public class TwoDGrid : IGrid
    {
        public TwoDGrid(int rows, int columns)
        {
            arrayObject = new int[rows, columns];
        }
        private int[,] arrayObject;

        /// <summary>
        /// Computes data and sets data to 2DArray
        /// </summary>
        public void ComputeData()
        {
            int[,] nextStat = Helper.DeepClone<int[,]>(arrayObject); // keep a copy so the original value is not lost

            for (int x = 0; x < arrayObject.GetLength(0); x++) // Loop each rows
            {
                for (int y = 0; y < arrayObject.GetLength(1); y++) // Print all values in the looped row
                {

                    //previousState[x, y] = 1;


                    int xMinusOne = x - 1;
                    int yMinusOne = y - 1;
                    int xPlusOne = x + 1;
                    int yPlusOne = y + 1;
                    int lives = 0;

                    if (xMinusOne < 0 || yMinusOne < 0 || yPlusOne > (arrayObject.GetLength(1) - 1) ||
                       xPlusOne > (arrayObject.GetLength(0) - 1))
                    {
                        continue;
                    }


                    //POS1
                    if (xMinusOne >= 0 && yMinusOne >= 0)
                        lives += arrayObject[xMinusOne, yMinusOne];
                    //POS2
                    if (xMinusOne >= 0)
                        lives += arrayObject[xMinusOne, y];
                    //POS3
                    if (xMinusOne >= 0 && yPlusOne <= (arrayObject.GetLength(1) - 1))
                        lives += arrayObject[xMinusOne, yPlusOne];
                    //POS4
                    if (yMinusOne >= 0)
                        lives += arrayObject[x, yMinusOne];
                    if (yPlusOne <= (arrayObject.GetLength(1) - 1))
                        lives += arrayObject[x, yPlusOne];
                    if (xPlusOne <= (arrayObject.GetLength(0) - 1) && yMinusOne >= 0)
                        lives += arrayObject[xPlusOne, yMinusOne];
                    if (xPlusOne <= (arrayObject.GetLength(0) - 1))
                        lives += arrayObject[xPlusOne, y];
                    if (xPlusOne <= (arrayObject.GetLength(0) - 1) && yPlusOne <= (arrayObject.GetLength(1) - 1))
                        lives += arrayObject[xPlusOne, yPlusOne];
                    //Any live cell with two or three live neighbours lives
                    //Any dead cell with exactly three live neighbours will
                    //if ((lives >= 2 && lives <= 3) && nextStat[x, y] == 1)
                    //{
                    //    nextStat[x, y] = 1;
                    //}
                    if (lives == 3 && arrayObject[x, y] == 0)
                    {
                        nextStat[x, y] = 1;
                    }
                    //Any live cell with fewer than two live neighbours dies 
                    //Any live cell with more than three live neighbours dies
                    else if ((lives < 2 || lives > 3) && arrayObject[x, y] == 1)
                    {
                        nextStat[x, y] = 0;
                    }


                }

            }

            arrayObject = nextStat;
            // return nextStat;
        }
        /// <summary>
        /// returns 2D array object
        /// </summary>
        /// <returns></returns>
        public int[,] TwoDGridInstance()
        {
            return arrayObject;
        }

        /// <summary>
        /// Sets data to 2D Array object
        /// </summary>
        /// <param name="initalValue"></param>
        public void SetIntialValue(int[,] initalValue)
        {
            arrayObject = initalValue;
        }
    }
}
