﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGOLLibrary.Interface
{
    public interface IGrid
    {
        void ComputeData();
        int[,] TwoDGridInstance();
        void SetIntialValue(int[,] initalValue);
    }
}
