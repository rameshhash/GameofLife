﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TGOLLibrary.Implementation;
using TGOLLibrary.Interface;

namespace TGOLTestProject
{
    [TestClass]
    public class UnitTestTGOL
    {
        [TestMethod]
        public void CreateObjectTest()
        {
            GridFactory gridObject = new GridCreator();
            IGrid twoDGridObject = gridObject.GetGrid("TwoD", 25, 25);
            Assert.IsNotNull(twoDGridObject);
        }
        [TestMethod]
        public void CompteObjectTest()
        {
            GridFactory gridObject = new GridCreator();
            IGrid twoDGridObject = gridObject.GetGrid("TwoD", 25, 25);
            var instanceData = twoDGridObject.TwoDGridInstance();

            instanceData.SetValue(1,1,1);
            twoDGridObject.SetIntialValue(instanceData);
            twoDGridObject.ComputeData();

            Assert.IsNotNull(twoDGridObject.TwoDGridInstance());
        }
    }
}
