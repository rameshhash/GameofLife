﻿using System; 
using TGOLLibrary.Implementation;
using TGOLLibrary.Interface;

namespace TGOL
{
    class Program
    {
        static void Main(string[] args)
        {
            Program cs = new Program();
            cs.Execute();
            
        }
        public void Execute()
        {
            string inputData = string.Empty;

            Console.WriteLine("Which generations's population positions are you interested in?");
            int generationCount = Convert.ToInt32(Console.ReadLine());
            // initialize 2D array

            GridFactory gridObject = new GridCreator();
            IGrid twoDGridObject = gridObject.GetGrid("TwoD", 25, 25);
            var instanceData = twoDGridObject.TwoDGridInstance();

            Console.WriteLine("Input the population positions of Generation ZERO!!!");
            Console.WriteLine("Press X to finish the input");

            // get input, until user keys x
            while (true)
            {
                inputData = PromptInput();
                if (inputData.ToLower() == "x")
                    break;
                // set value to 2D array
                instanceData.SetValue(1, Convert.ToInt32(inputData.Split(' ')[0]), Convert.ToInt32(inputData.Split(' ')[1]));

            }

            // set data for population
            twoDGridObject.SetIntialValue(instanceData);



            // based on the genereation input execute compute data
            for (int i = 0; i < generationCount; i++)
            {
                twoDGridObject.ComputeData();
            }
            PrintValues(twoDGridObject.TwoDGridInstance());

            Console.WriteLine("Press Y for getting new generation set!! or any other key to exit");
            var continueValue = Console.ReadLine();

            if (continueValue.ToLower() == "y")
                Execute();
        }

        /// <summary>
        /// Gets input from console
        /// </summary>
        /// <returns></returns>
        private string PromptInput()
        {
            return Console.ReadLine();
        }

        /// <summary>
        /// Prints to console. this can be replaced with other UI outputs
        /// </summary>
        /// <param name="vs"></param>
        public void PrintValues(int[,] vs)
        {

            //   File.WriteAllLines(@"C:/Temp/data1.csv", ToCsv(vs));
            for (int i = 0; i < vs.GetLength(0); i++) // Loop each rows
            {

                for (int j = 0; j < vs.GetLength(1); j++) // Print all values in the looped row
                {
                    //  Console.Write(string.Format("{0}\t", vs[i, j])); 
                    if (vs[i, j] == 1)
                    {
                        Console.Write("(");
                        Console.Write(i.ToString());
                        Console.Write(",");
                        Console.Write(j.ToString());
                        Console.Write(")");
                        Console.Write(",");
                        Console.Write(" ");

                        Console.WriteLine("");
                    }
                }

                Console.WriteLine("");
            }
        }
    
    }
}
// ---------------------------------------------------------------------------------------
// Draft version
// Seed > Gen 0> Computation > Gen1 > Computation > GenX
// Step 1. Get Inital seed value -- Can be done later
// Step 2. Assign the seed value to master object -- [array]
// Step 3. Clone a copy of master object to computation object
// Step 4. Compute next generation value based on master and assign values to computation object
// Step 5. Assign  computation object value to next generation value

// formula to get neibhours
//x-1,y-1 x - 1,y x-1, y + 1
//x ,y-1	x, y	x, y+1
//x+1, y-1	x+1 , y	x+1, y +1

//Input > 1. Grid size, 2. Alive position